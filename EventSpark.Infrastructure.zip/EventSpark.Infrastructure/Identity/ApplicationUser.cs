﻿using Microsoft.AspNetCore.Identity;
namespace EventSpark.Infrastructure.Identity
{
    public class ApplicationUser: IdentityUser
    {
    }
}
