﻿namespace EventSpark.Infrastructure
{
    public class Class1
    {

    }
}
