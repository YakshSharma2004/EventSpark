﻿namespace EventSpark.Core.Auth
{
    public static class AppRole
    {
        public const string Admin = "Admin";
    }
}
