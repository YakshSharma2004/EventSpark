﻿namespace EventSpark.Web.Models
{
    public class PaymentStatusViewModel
    {
        public int OrderId { get; set; }
        public decimal TotalAmount { get; set; }
    }
}
